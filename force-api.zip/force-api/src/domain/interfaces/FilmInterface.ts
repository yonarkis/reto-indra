export interface FilmInterface {
    url: string;
}