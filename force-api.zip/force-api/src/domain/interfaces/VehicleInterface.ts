export interface VehicleInterface {
    url: string;
}