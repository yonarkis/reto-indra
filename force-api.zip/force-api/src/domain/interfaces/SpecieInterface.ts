export interface SpecieInterface {
    url: string;
}