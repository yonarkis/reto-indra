export interface StarshipInterface {
    url: string;
}