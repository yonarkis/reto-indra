export interface ExternalApiService {
    getPeopleById(id: number): any;
}
