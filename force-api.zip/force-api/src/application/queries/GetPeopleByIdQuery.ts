export class GetPeopleByIdQuery {
    id: number;
    constructor(id: number) {
        this.id = id;
    }
}