export class EspecieInterfaz {
    url: string;
}