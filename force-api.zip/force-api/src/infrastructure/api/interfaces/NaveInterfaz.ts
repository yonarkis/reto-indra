export class NaveInterfaz {
    url: string;
}