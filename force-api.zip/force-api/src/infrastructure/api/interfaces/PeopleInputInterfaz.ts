export interface PeopleInputInterfaz {
    id: number;
    nombre: string;
    año_de_nacimiento: string;
    color_de_ojos: string;
    genero: string;
    color_de_pelo: string;
    peso: string;
    masa: string;
    color_de_piel: string;
    mundo_natal: string;
    url: string;
}