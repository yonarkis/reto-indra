export interface PeliculaInterfaz {
    url: string;
}