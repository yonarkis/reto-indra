export interface VehiculoInterfaz {
    url: string
}