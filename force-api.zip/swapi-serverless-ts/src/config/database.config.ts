import AWS from 'aws-sdk';

export const dynamoDB = new AWS.DynamoDB.DocumentClient();
