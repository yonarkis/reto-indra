export interface ProductI {
  id: string;
  title: string;
  price: number;
  size: string;
  stock: number;
}
