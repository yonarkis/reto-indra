export const mapProduct = {
  id: 'id',
  price: 'precio',
  size: 'talla',
  stock: 'existencias',
  title: 'titulo',
};
