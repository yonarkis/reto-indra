export const httpMessages = {
  internalServerError: 'Internal Server Error',
};
